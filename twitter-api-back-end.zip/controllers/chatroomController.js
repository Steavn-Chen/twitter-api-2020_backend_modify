const chatroomController = {
  getChatroom: (req, res) => {
    return res.render('chatroom')
  }
}

module.exports = chatroomController